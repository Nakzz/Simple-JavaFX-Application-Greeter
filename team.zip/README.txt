# Simple-JavaFX-Application-Greeter

Course: cs400
Semester: Spring 2019
Project name: JavaFX Greeter
Team Members:
1. Ajmain Naqib, 002, naqib@wisc.edu

Notes or comments to the grader: